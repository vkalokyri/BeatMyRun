package edu.rutgers.cs.rahul.helloworld.tests;

import android.app.Application;
import android.test.ApplicationTestCase;
/*
* Created by Valia Kalokyri
* Tested by Valia Kalokyri
* Debugged by Valia Kalokyri
 */
/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
}
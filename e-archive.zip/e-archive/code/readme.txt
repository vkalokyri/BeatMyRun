ReadMe
The code can be found in the repository https://github.com/vkalokyri/BeatMyRun.git
1. Download �the installer to your PC and launch the .dmg/.exe �file from the 

Android Studio home page link below

https://developer.android.com/sdk/

2. Follow the instructions on the setup wizard to install Android Studio

Adding & Installing Packages

3. Click �SDK manager� in the toolbar and select one of the following from the 

Tools directory: 

? Android SDK Tools 

? Android SDK Platform-tools 

? Android SDK Build-tools (select the highest version)

4. And/Or select the following from the Android X.X (latest version) folder: 

? SDK Platform 

? System image for emulation, with CPU/ABI Intel Atom(x86_64) , 

5. Click Install X packages

6. Accept the license agreement

7. Click Install

8. Get key from Google API and YouTube API for the Login and streaming music 

https://developers.google.com/api-client-library/php/guide/aaa_apikeys#acquiring-

an-api-key

https://developers.google.com/youtube/v3/getting-started

9. Include your Android and Browser API keys in the file LoginActivity.java

10. Generate your google-services.json file using your API keys

11. Include your google-services.json file in the /app level of the project

12. Run LoginActivity

API 22 System Image